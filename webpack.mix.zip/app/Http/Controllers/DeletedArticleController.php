<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Article;
use App\DeletedArticle;

class DeletedArticleController extends Controller
{
    //
}
