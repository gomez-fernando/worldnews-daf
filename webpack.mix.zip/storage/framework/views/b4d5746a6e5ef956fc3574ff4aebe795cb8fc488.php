<?php $__env->startSection('title'); ?>
    <title>Publicar</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">
                        Publicar artículo
                    </div>
                    <div class="card-body">
                        <form action="<?php echo e(route('editor.publish')); ?>" method="POST" id="" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" value="<?php echo e($article->id); ?>" name="id" id="" />

                            <input type="hidden" value="<?php echo e($article->edited_by); ?>" name="editedBy" id="" />
                            

                            
                            
                            
                            
                            

                            

                            <div class="form-group row">
                                <label for="title" class="col-md-3 col-form-label text-md-right">Título</label>
                                <div class="col-md-8">
                                    <input type="text" value="<?php echo e($article->title); ?>" id="title" name="title" class="form-control" required>

                                    
                                    <?php if($errors->has('title')): ?>
                                        <span class="alert-danger" role="alert">
                                    <strong><?php echo e($errors->first('title')); ?></strong>
                                    </span>

                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="sub_title" class="col-md-3 col-form-label text-md-right">Subtítulo</label>
                                <div class="col-md-8">
                                    <input type="text" value="<?php echo e($article->sub_title); ?>" id="sub_title" name="sub_title" class="form-control" required>

                                    
                                    <?php if($errors->has('sub_title')): ?>
                                        <span class="alert-danger" role="alert">
                                    <strong><?php echo e($errors->first('sub_title')); ?></strong>
                                    </span>

                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="created_at" class="col-md-3 col-form-label text-md-right">Creado</label>
                                <div class="col-md-8">
                                    <input readonly value="<?php echo e($article->created_at); ?>" type="text" id="created_at" name="" class="form-control" required>
                                </div>
                            </div>

                            
                            
                            
                            
                            
                            

                            <div class="form-group row">
                                <label for="section" class="col-md-3 col-form-label text-md-right">Sección</label>
                                <div class="col-md-8">
                                    <select  type="select" id="section" name="section" class="form-control" required>
                                        <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($section->id); ?>"
                                                    <?php if($section->id == $article->section_id): ?>
                                                    selected
                                                <?php endif; ?>
                                            ><?php echo e($section->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>

                                    
                                    <?php if($errors->has('section')): ?>
                                        <span class="alert-danger" role="alert">
                                    <strong><?php echo e($errors->first('section')); ?></strong>
                                    </span>

                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group row">
                                <div class="col-md-10 offset-md-1">
                                    <img class="preview-img" src="<?php echo e(route('article.file', ['filename' => $article->image_path])); ?>" class="avatar" alt="">
                                </div>
                            </div>

                            

                            <div class="form-group row">
                                <label for="image_path" class="col-md-3 col-form-label text-md-right">Cambiar imagen</label>
                                <div class="col-md-8">
                                    
                                    <input type="file" id="image_path" name="image_path" class="form-control  <?php echo e($errors->has('image_path') ? 'is-invalid' : ''); ?>" />

                                    
                                    <?php if($errors->has('image_path')): ?>
                                        <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('image_path')); ?></strong>
                                    </span>

                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="keywords" class="col-md-3 col-form-label text-md-right">Tags</label>
                                <div class="col-md-8">
                                    <input type="text" value="<?php echo e($article->keywords); ?>" id="keywords" name="keywords" class="form-control" required autofocus>


                                    
                                    <?php if($errors->has('keywords')): ?>
                                        <span class="alert-danger" role="alert">
                                    <strong><?php echo e($errors->first('keywords')); ?></strong>
                                    </span>

                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="slug" class="col-md-3 col-form-label text-md-right"><?php echo e(__('Slug')); ?></label>
                                <div class="col-md-8">
                                    <input type="text" value="<?php echo e($article->slug); ?>" id="slug" name="slug" class="form-control" required>

                                    
                                    <?php if($errors->has('slug')): ?>
                                        <span class="alert-danger" role="alert">
                                    <strong><?php echo e($errors->first('slug')); ?></strong>
                                    </span>

                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="text" class="col-md-3 col-form-label text-md-right">Texto</label>
                                <div class="col-md-8">
                                    <textarea id="text" name="text" class="form-control" required><?php echo e($article->text); ?></textarea>

                                    <script src="<?php echo e(asset('vendor/unisharp/laravel-ckeditor/ckeditor.js')); ?>"></script>

                                    <script>
                                        // Replace the <textarea id="editor1"> with a CKEditor
                                        // instance, using default configuration.
                                        CKEDITOR.replace( 'text' );
                                    </script>

                                    
                                    <?php if($errors->has('text')): ?>
                                        <span class="alert-danger" role="alert">
                                    <strong><?php echo e($errors->first('text')); ?></strong>
                                    </span>

                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="state" class="col-md-3 col-form-label text-md-right">Estado</label>
                                <div class="col-md-8">
                                    <input type="text" readonly value="<?php echo e($article->state); ?>" id="state" name="" class="form-control" required>

                                    
                                    <?php if($errors->has('state')): ?>
                                        <span class="alert-danger" role="alert">
                                    <strong><?php echo e($errors->first('state')); ?></strong>
                                    </span>

                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="editorComments" class="col-md-3 col-form-label text-md-right">Comentarios del editor</label>
                                <div class="col-md-8">
                                    <textarea <?php if(Auth::user() && Auth::user()->usertype != 'editor'): ?>
                                              readonly
                                              <?php endif; ?> id="editorComments" name="editorComments" class="form-control" required autofocus><?php echo e($article->editor_comments); ?> <?php echo e(old('editorComments')); ?> </textarea>

                                    
                                    <?php if($errors->has('editorComments')): ?>
                                        <span class="alert-danger" role="alert">
                                    <strong><?php echo e($errors->first('editorComments')); ?></strong>
                                    </span>

                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group row justify-content-center">
                                <div class="form-group row">
                                    <div class="col-md-6 offset-md-3">
                                        <input type="submit" name="submitState" value="Devolver al autor" class="btn btn-primary"  />
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <div class="col-md-6 offset-md-3">
                                        <input type="submit" name="submitState" value="Publicar" class="btn btn-primary" />
                                    </div>
                                </div>
                            </div>

                        </form>
                    </div>
                </div>

            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>