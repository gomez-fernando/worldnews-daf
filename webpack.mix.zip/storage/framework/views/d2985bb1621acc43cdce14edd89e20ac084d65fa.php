<?php $__env->startSection('title'); ?>
    <title>Panel de control</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-12">
                
                <?php echo $__env->make('includes.message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
        </div>
        <div class="row">


            <h3>Noticias pendientes de publicar</h3>
            <table class="table table-striped">
                <thead>
                <tr>
                    <th scope="col">Título</th>
                    <th scope="col">Fecha de creación</th>
                    <th scope="col">Revisar</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $inReviewArticles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inReviewArticle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($inReviewArticle->title); ?></th>
                        <td><?php echo e($inReviewArticle->created_at); ?></td>
                        <td>
                            <a href="<?php echo e(route('editor.publishView', ['id' => $inReviewArticle->id])); ?>" class="btn btn-sm btn-warning">Revisar</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

        </div>

        <hr>


        <div class="row">
            <h3>Noticias para republicar</h3>
            <table class="table table-striped">
                <thead>
                <tr>
                    <th scope="col">Título</th>
                    <th scope="col">Fecha de creación</th>
                    <th scope="col">Revisar</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $inReviewPublishedArticles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inReviewPublishedArticle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($inReviewPublishedArticle->title); ?></th>
                        <td><?php echo e($inReviewPublishedArticle->created_at); ?></td>
                        <td>
                            <a href="<?php echo e(route('editor.rePublishView', ['id' => $inReviewPublishedArticle->id])); ?>" class="btn btn-sm btn-warning">Revisar</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>