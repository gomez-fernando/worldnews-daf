<?php $__env->startSection('title'); ?>
    <title>Resultados de la búsqueda</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <h3>Artículos coincidentes con la búsqueda: "<?php echo e($search); ?>"</h3>
            <table class="table table-striped">
                <thead>
                <tr>
                    <th scope="col">Título</th>
                    <th scope="col">Tags</th>
                    <th scope="col">Ver</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($article->title); ?></th>
                        <td> <?php
                            $string = $article->keywords;
                            $str_arr = explode (";", $string);
                            echo '<ul>';
                            echo '<li>' . implode( '</li><li>', $str_arr) . '</li>';
                            echo '</ul>';
                            ?></td>
                        <td>
                            <a href="<?php echo e(route('article.detail', ['id' => $article->id])); ?>" class="btn btn-sm btn-warning">Revisar</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

            
        </div>
        <div class="row justify-content-center">

        </div>

        </div>

    <!-- </div>

    </div>

    </div> -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>